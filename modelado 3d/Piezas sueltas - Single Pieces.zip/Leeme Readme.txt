ES

¡GRACIAS POR APOYAR MI TRABAJO!

A continuación te dejo unos enlaces que te serán de gran utilidad para llevar a cabo este proyecto.

Vídeo de construcción
https://www.youtube.com/watch?v=CLMRyQPhmR8

Carrocerías:
Challenger: https://www.youtube.com/watch?v=xn2Gs-fWk54
Delorean: https://www.youtube.com/watch?v=fJKUTqXcYE0&t

No te pierdas imágenes y videos de este y de otros proyectos siguiendome en redes sociales.
https://www.youtube.com/dukedoks/
https://www.instagram.com/dukedoks/

Si lo que más te interesa es el mundo radiocontrol impreso en 3D, tengo una cuenta de Instagram solo para eso.
https://www.instagram.com/dukedoks_rc/

Para apoyar mi trabajo de forma gratuita puedes seguirme en redes y compartir tus impresones 3D de mis proyectos conmigo.
También puedes utilizar los enlaces de compra que encontrarás en las guías de construcción, de esta forma tu pagarás lo mismo y yo me llevaré un pequeño porcentaje.
Y sobre todo descargando mis diseños y comprando algunos de ellos.


Duke Doks
www.dukedoks.com






EN

THANK YOU FOR SUPPORTING MY WORK!

Here are some links that will be very useful for you to carry out this project

Build video
https://www.youtube.com/watch?v=CLMRyQPhmR8

Bodies:
Challenger: https://www.youtube.com/watch?v=xn2Gs-fWk54
Delorean: https://www.youtube.com/watch?v=fJKUTqXcYE0&t

Take a look at other projects by following me on social media
https://www.youtube.com/dukedoks/
https://www.instagram.com/dukedoks/

If you love 3D printed RC projects, I have an Instagram account just for that!
https://www.instagram.com/dukedoks_rc/

To support my work for free you can follow me on social networks and share your 3D prints of my projects with me.
You can also use the purchase links that you will find in the building guides, this way you will pay the same and I will take a small percentage.
And the better way, downloading my designs and buying some of them!


Duke Doks
www.dukedoks.com
